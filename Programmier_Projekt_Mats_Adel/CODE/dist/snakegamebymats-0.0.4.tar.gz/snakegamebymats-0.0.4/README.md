# Schlangen
Das Projekt ist eine simple interrpretertion des Schlangen Spiels.
Wenn der Spieler sich nach voren bewegt hinterlässt die Schlange eine Spur,
welcher einer Schlange ähnlich ist. Man verliert wenn man mit sich selbst
oder mit einer Wand kollidiert.

Wenn man das Programm laufen lässte wird man als erstes mit einem Popupfentster 
konfrontiert, in welchem man seinen Namen definiert. Wenn man dies getan hat 
beginnt das Spiel mit einem Countdown.

Die Steuerung ist mit den Bewegungskeys:
- "up"
- "down"
- "left"
- "right"

Ich habe Pygame und Tkinter benutzt

pypi Link: https://pypi.org/project/snakegamebymats/0.0.3/
